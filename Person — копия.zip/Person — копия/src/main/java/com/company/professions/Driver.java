package com.company.professions;


import com.company.entities.Person;

public class Driver extends Person  {

       int drivingExperience;

}
