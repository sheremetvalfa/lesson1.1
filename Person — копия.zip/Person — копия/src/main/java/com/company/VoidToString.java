package com.company;

public interface VoidToString {
    void start();
    void stop();
    void ternRight();

    void ternLeft();

}
