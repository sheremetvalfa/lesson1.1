package com.company.entities;

public class Person {
    public String name ;
    public int age;
    public String sex ;
    public String numberPhone ;
     public Person(String name, int age, String sex, String numberPhone){
        this.name = name;
        this.age = age;
        this.sex = sex;
        this.numberPhone = numberPhone;

    }


}

