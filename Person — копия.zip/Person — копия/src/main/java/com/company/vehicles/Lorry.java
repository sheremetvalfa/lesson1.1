package com.company.vehicles;

public class Lorry extends Car{
    String weightSuper = "2000+ weight";
}
