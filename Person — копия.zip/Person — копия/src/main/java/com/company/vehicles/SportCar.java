package com.company.vehicles;

public class SportCar extends Car {
    int maxSpeed = 300;
}

